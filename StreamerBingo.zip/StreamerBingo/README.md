# Streamer Bingo
[[Download .exe](https://github.com/BNK3R-Boy/StreamerBingo/raw/main/StreamerBingo.exe)][[Virus Total Prüfergebnis](https://www.virustotal.com/gui/url/29ad4db5ec0e4aa39cdad467b9d04deb1610fa35205d87b6b672ac5609fa2f5b?nocache=1)]

[[Download .zip](https://github.com/BNK3R-Boy/StreamerBingo/raw/main/StreamerBingo.zip)][[Virus Total Prüfergebnis](https://www.virustotal.com/gui/url/9b20b70df153ede6de3ffe07fc8c46f782202d10d94b0aa6d4bd5e437b53242e?nocache=1)]

[[Autohotkey Quellcode](https://github.com/BNK3R-Boy/StreamerBingo/blob/main/StreamerBingo.ahk)] v1.4




#### Updates (Aktuelle Version: 1.4)

_Schneller und häufiger als gedacht, tut mir leid._

1.3 - Abwärtsinkompatibel, zu starke veränderung an der Spielscheinnummer.

1.4 - nicht mehr Abwärtskompatibel




#### INFO! 

Um das Spiel zu Starten, einfach einen doppel klick auf StreamerBingo.exe.

Um einen Spielschein zu Kontrolieren, die Spielscheinnummer in der Zwischenablage speichern und doppel klick auf StreamerBingo.exe

oder eine Verknüpfung anlegen und hinter StreamerBingo.exe die Spielscheinnummer einfügen.

zb: "C:\Users\[Dein Windows Benutzername]\Desktop\StreamerBingo.exe 6:18:2:12:17:14:16:7:3::20:1424:186"




#### Wichtige Dateien:

StreamerBingo.exe						- das Spiel

triggercontainer20220916Yvraldis.txt	- der Datensatz




# The Game

Startet ganz einfach die App mit einem doppel Klick und schon geht es los. Ihr bekommt einen Spielschein Generiert und Ihr braucht nur noch auf die Schlagworte klicken.

![preview](https://user-images.githubusercontent.com/17516608/188402859-e4f49404-c79d-4294-9a24-eba538e54ec9.png)

Ein Bingo sind 3 in einer Reihe, egal ob horizontal, vertical oder diagonal.

Nach dem Ihr ein Bingo habt klickt Ihr auf den untere "Bingo!" Schaltfläche um das Ergebnis in die Zwischenablage abzulegen.

Nun nur die Chateingabe auswählen und Einfügen (strg+v) und Enter drücken.

![preview](https://user-images.githubusercontent.com/17516608/189213825-e99b19ba-47cb-4b57-9ea9-f7e2989faf8a.png)




Viel Spaß beim Bingo spielen.




# Trigger Container:

triggercontainer20220904.txt

oder

triggercontainer[Datum].txt (ohne Eckige Klammern)


Jede Zeile ist ein Schlagwort.

![preview2](https://user-images.githubusercontent.com/17516608/188405336-263f3edd-4ec2-41ba-8203-154cd050a79e.png)




# Info

Wer ganz sicher gehen möchte, was sich in der Compilierten .EXE befinden, kann diese mit 7zip Öffen.

Dazu klickt Ihr mit rechts auf die StreamerBingo.exe und im Kontextmenü auf 7zip / Öffnen. Navigiert nach StreamerBingo.exe\.rsrc\RCDATA\ und dort findet Ihr die ">AUTOHOTKEY SCRIPT<" Datei, die das Script beinhaltet und die "TRIGGERCONTAINER20220904.TXT" Datei die erzeugt wird.

Mit einem rechts Klick auf die Datei und wieder im Kontextmenü auf Ansehen oder Bearbeiten klicken um den Inhalt zu sehen.

---
*"Is it possible to decompile the AHK executable?"*

[yes it is possible to decompile. you need 7-zip. right-click executable and from 7-zip menu, select "Open as Archive" . after you opened click on RSRC folder. then goto rcdata folder. right-click the file named ">AUTOHOTKEY SCRIPT<" and click "edit" . its the source of the file](https://www.autohotkey.com/boards/viewtopic.php?p=397453&sid=370e5dd320cf15a3272e8d3b7d855c30#p397453)

